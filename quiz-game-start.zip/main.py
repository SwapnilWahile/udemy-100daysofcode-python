from question_model import Question
from data import question_data
from quiz_brain import QuizBrain

question_bank = []
for que in question_data:
  my_q = Question(que["question"], que["correct_answer"])
  question_bank.append(my_q)
#print(question_bank[1].text)
quiz = QuizBrain(question_bank)
while quiz.is_que_remaining():
  quiz.next_question()
print("You've completed the quiz")
print(f"your final score is: {quiz.score}/{quiz.question_number}")


