class QuizBrain:
  def __init__(self, ques_bank):
    self.question_number = 0
    self.question_list = ques_bank
    self.score = 0

  def is_que_remaining(self):
    if self.question_number < len(self.question_list):
        return True
    else:
      return False

  def next_question(self):
    que = self.question_list[self.question_number]
    self.question_number += 1
    choice = input(f"Q.{self.question_number} {que.text} (True/False): ")
    self.check_answer(choice, que.answer)

  def check_answer(self, choice, correct_ans):
    if choice == correct_ans:
      print("you got it right")
      self.score += 1
    else:
      print("That's Wrong")
    print(f"correct answer was {correct_ans}.")
    print(f"your current score is: {self.score}/{self.question_number}")
        